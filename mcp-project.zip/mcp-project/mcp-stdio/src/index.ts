import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
// -------------实现一个两数相加-------------

// 创建一个mcp服务器实例的构造函数
const server = new McpServer({
  name: "testadd", //mcp服务器的名字
  version: "1.0.0", //mcp版本号，主要用来调试
  capabilities: {},
});

// 注册工具
server.tool(
  "add", //工具名称
  "计算两个数字之和", //描述
  {
    a: z.number().describe("第一个数字"),
    b: z.number().describe("第二个数字"),
  },
  async ({ a, b }) => {
    const sum = a + b;
    return {
      content: [
        {
          type: "text",
          text: `${a}和${b}相加结果是${sum}`,
        },
      ],
    };
  }
);

// 启动mcp服务器
async function main() {
  // 创建一个stdio的实例
  const transport = new StdioServerTransport();
  // 将mcp服务挂载在实例的通道上
  await server.connect(transport);
  console.error("mcp服务启动成功");
}

main().catch((err) => {
  console.error("mcp出错", err);
});
