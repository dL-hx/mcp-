<template>
  <view class="chat-message" v-for="(item, index) in messageList" :key="index">
    <!-- 用户消息 -->
    <view class="user-message" v-if="item.role == 'user'">
      {{ item.content }}
    </view>
    <!-- 模型消息 -->
    <view class="ai-message" v-if="item.role == 'assistant' && item.modelContent.length > 0">
      <template v-for="(itema, indexa) in item.modelContent" :key="indexa">
        <!-- 深度思考· -->
        <view class="deep-thinking-view" v-if="itema.type == 'deepThinking'">
          <text class="title-text">深度思考</text>
          <view class="deep-thinking" v-html="marked(itema.content)"></view>
        </view>
        <!-- mcp工具 -->
        <view class="deep-thinking-view" v-if="itema.type == 'mcpContent'">
          <text class="title-text">工具调用</text>
          <view class="deep-thinking tool-style">{{ itema.content }}</view>
        </view>
        <!-- 总结内容 -->
        <view v-if="itema.type == 'modelSummary'" v-html="marked(itema.content)"></view>
      </template>
    </view>
  </view>
  <!-- 输入框 -->
  <view style="height: 300rpx"></view>
  <view class="chat-input">
    <view class="user-input">
      <input type="text" v-model="userInput" />
    </view>
    <view class="user-send">
      <button type="primary" class="is-hover" @click="send">发送</button>
    </view>
  </view>
</template>

<script setup>
import { ref } from "vue";
const userInput = ref("");
const url = "http://127.0.0.1:3500/chat";
import { marked } from "marked";
// 对话列表
const messageList = ref([]);
const send = async () => {
  if (userInput.value.trim() === "") return;
  messageList.value.push({ role: "user", content: userInput.value.trim() });
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userContent: userInput.value }),
  });
  userInput.value = "";
  if (!response.ok) {
    throw new Error("发送失败");
  }
  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error("模型响应失败");
  }
  messageList.value.push({ role: "assistant", modelContent: [] });
  const aiMessageObj = messageList.value[messageList.value.length - 1];
  while (true) {
    const { done, value } = await reader.read();
    if (done) {
      console.log("大模型回复完毕");
      break;
    }
    const chunk = new TextDecoder("utf-8").decode(value, { stream: true });
    let parts = chunk.split("###ABC###");
    for (const part of parts) {
      if (part.trim() === "") continue;
      const aiMessage = JSON.parse(part);
      console.log(aiMessage);
      // 模型回复
      if (aiMessage.role === "assistant") {
        const type = aiMessage.type;
        const content = aiMessage.content;
        if (["deepThinking", "modelSummary", "mcpContent"].includes(type)) {
          const existing = aiMessageObj.modelContent.find((item) => item.type === type);
          if (existing) {
            existing.content += content;
          } else {
            aiMessageObj.modelContent.push({ type, content }); // 首次添加该类型
          }
          aiMessageObj.modelContent = [...aiMessageObj.modelContent];
        }
      }
    }
  }
};
const renderContent = (content) => {
  // 是数组 / 对象，转为 Markdown 格式 JSON 代码块
  return marked("```json\n" + JSON.stringify(content, null, 2) + "\n```");
};
</script>

<style>
page {
  background-color: #f6f7fb;
}
view,
text {
  font-size: 33rpx;
}
.chat-message {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  margin: 0 10rpx;
}
.user-message {
  max-width: 70%;
  align-self: flex-end;
  background-color: #3a71e8;
  border-radius: 10rpx;
  padding: 8rpx;
  color: #ffffff;
  margin-top: 30rpx;
  word-break: break-all;
  white-space: pre-wrap;
  overflow-wrap: break-word;
}
.ai-message {
  background-color: #ffffff;
  border-radius: 10rpx;
  padding: 8rpx;
  margin-top: 30rpx;
}
.deep-thinking-view {
  margin-bottom: 10rpx;
}
.title-text {
  font-weight: bold;
  color: blue;
}
.deep-thinking {
  background-color: #f5f5f5;
  font-size: 28rpx;
  border-radius: 10rpx;
  padding: 4rpx;
  margin-top: 5rpx;
  line-height: 1.5;
}
.deep-thinking pre {
  white-space: pre-wrap;
  word-wrap: break-word;
}
.tool-style {
  height: 70rpx;
  line-height: 70rpx;
}
.chat-input {
  background-color: #ffffff;
  position: fixed;
  bottom: 0;
  right: 0;
  left: 0;
  /* padding-bottom: 48rpx; */
  padding: 10rpx 15rpx 48rpx 15rpx;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.user-input {
  /* background-color: #3a71e8; */
  width: 100%;
  padding: 10rpx;
}
.user-send {
  width: 200rpx;
}
.is-hover {
  font-size: 28rpx;
}
</style>
