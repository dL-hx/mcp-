import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { ChatCompletionTool } from "openai/resources/chat/completions";

const client = new Client({
  name: "mcp-client-qwen",
  version: "1.0.0",
});
// 返回的工具列表
let tools: ChatCompletionTool[] = [];
export async function connectMcp() {
  const mcpUrl = new URL("https://ai.weiniai.cn/mcp/"); //https://ai.weiniai.cn/mcp/
  const transport = new StreamableHTTPClientTransport(mcpUrl);
  await client.connect(transport);
  const toolsRes = await client.listTools();
  tools = toolsRes.tools.map((item) => ({
    type: "function",
    function: {
      name: item.name,
      description: item.description,
      parameters: item.inputSchema,
    },
  }));
  console.log("mcp客户端已经连接到服务器，获取到工具列表---" + JSON.stringify(tools));
}

export function getMcpClient() {
  return client;
}
export function getTools() {
  return tools;
}
