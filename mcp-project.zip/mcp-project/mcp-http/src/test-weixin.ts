import { chromium } from "playwright";

async function crawlWeixin(url: string) {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  try {
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 20000 });
    await page.waitForSelector("#js_content", { timeout: 10000 });
    const content = await page.$eval("#js_content", (el) => el.textContent?.trim());
    console.log("爬取到的内容----------" + content);
  } catch (error) {
    console.error("爬取失败", error);
  } finally {
    // 关闭浏览器
    await browser.close();
  }
}

crawlWeixin("https://mp.weixin.qq.com/s/WWivv1GNSRieJ7Lv3CpsuQ");
